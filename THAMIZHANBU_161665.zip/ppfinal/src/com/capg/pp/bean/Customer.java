package com.capg.pp.bean;



public class Customer {
    String name;
    int age;
    String address; 
    String pan;
    long mobNum;
    long aadhaar;
    long accountNum;
    double balance;
    
    
    
    public void setName(String name){
        this.name=name;
    }
    public String getName(){
        return this.name;
    }
    

    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }

    
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    
    public long getMobNum() {
        return mobNum;
    }
    public void setMobNum(long mobNum) {
        this.mobNum = mobNum;
    }
    
    
   
    
    public long getAadhaar() {
        return aadhaar;
    }
    public void setAadhaar(long aadhaar) {
        this.aadhaar = aadhaar;
    }
    
    
    
    public String getPan() {
        return pan;
    }
    public void setPan(String pan) {
        this.pan = pan;
    }
    
    
    
    public double getBalance() {
        return balance;
    }
    public void setBalance(double balance) {
        this.balance = balance;
    }
    

    public long getAccountNum() {
        return accountNum;
    }
    public void setAccountNum(long accountNum) {
        this.accountNum = accountNum;
    }
    
    
    @Override
    public String toString(){
        return "\nName: "+name+ 
                "\nAccount Number: "+accountNum+
                "\nBalance: "+balance+  
                "\nAge: "+age+
                "\nMobile Number: "+mobNum+
                "\nAddress: "+address+
                "\nAadhaar Number: "+aadhaar+
                "\nPan Number: "+pan;
        
    }

}
