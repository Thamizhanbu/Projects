package com.capg.pp.dao;
import java.util.List;
import java.util.Map;

import com.capg.pp.bean.Customer;


public interface DaoInterface {

    public boolean createAccount(Customer c);
    public Customer customerDetails(long accnum);
    public Customer showBalance(long accnum);
    public Customer deposit(long accnum,double amount);
    public Customer withdraw(long accnum, double amount);
    public int fundTransfer(long accnum);
    public List<String> printTransaction(long accnum);
    public Map<Long,Customer> getAllCustomerDetails();
    
}