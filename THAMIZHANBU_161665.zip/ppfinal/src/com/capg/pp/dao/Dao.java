package com.capg.pp.dao;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.capg.pp.bean.Customer;

public class Dao implements DaoInterface{
    static Map<Long, Customer> map = new HashMap<Long, Customer>();
    Map<Long, List<String>> map2 = new HashMap<Long, List<String>>();
    List<String> list=new ArrayList<String>();
    
    
    public boolean saveTransaction(long accNum, String log)
    {
        
        if(map2.containsKey(accNum)) {
            map2.get(accNum).add(log);
        }
        return true;
    }
    
    public int validateAccnum(long accountNumber)
    {
        int result=0;
        boolean compare;
        for(long key:map.keySet()) {
           
            compare=key==accountNumber;
            if(compare==true) {
                result=1;
            }
         }
        return result;
    }

    public boolean createAccount(Customer c) {
        boolean result=false;
        map.put(c.getAccountNum(),c);
        list.add("account created successfully");
        map2.put(c.getAccountNum(),list );
        result=true;
        return result;
    }
    public Map<Long, Customer> getAllCustomerDetails(){
             return map;
    }

    public Customer customerDetails(long accnum) {
        Customer c1=null;
        for (Customer c : map.values()) {
            if (c.getAccountNum() == accnum) {
                c1=c;
            }
        }
        return c1;
    }
    
    
    public Customer showBalance(long accnum) {
        Customer c1=null;
        for (Customer c : map.values()) {
            if (c.getAccountNum() == accnum) {
                c1=c;
            }
        }
        return c1;
    }
    
    
    public Customer deposit(long accnum,double amount) {
       
        Customer c2=null;
        for (Customer c : map.values()) {
            if (c.getAccountNum() == accnum) {
                    c2=c;
        }
            }
        return c2;
    }
    
    
    public Customer withdraw(long accnum, double amount) {
 
        Customer c3 = null;
        for (Customer c : map.values()) {
            if (c.getAccountNum() == accnum) {
                        c3=c;
                       
            }
        }
        return c3;
    }
    
    
    public int fundTransfer(long accnum){
    
        int result=0;
        for(long key:map.keySet()) {
           
           if(key==accnum) {
                result=1;
            }
         }
        return result;
        
    }
    
    public List<String> printTransaction(long accnum){
      
           return map2.get(accnum);
       
    }

    
    
}