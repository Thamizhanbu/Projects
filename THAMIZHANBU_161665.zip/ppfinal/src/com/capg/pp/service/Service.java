package com.capg.pp.service;
import com.capg.pp.exception.*;

import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capg.pp.bean.Customer;
import com.capg.pp.dao.Dao;
public class Service implements ServiceInterface{
    
    Dao d=null;
    double check;
    
    
    public boolean validateName(String name2) throws BankAccountException
    {
    boolean flag=false;
    Pattern name=Pattern.compile("^[A-Z][A-za-z,\\s]+");
    Matcher nameMatch=name.matcher(name2);
    if(nameMatch.matches())
    {
        flag=true;
    }
    else
    {
        flag=false;
    }
    return flag;
    }
    
    
    public boolean validateAge(int age) throws BankAccountException
    {
    boolean flag=false;
    if(age>=18&&age<=60)
    {
        flag=true;
    }
    else
    {
        flag=false;
    }
    return flag;
    }
    
    
    public boolean validateAddress(String address) throws BankAccountException
    {
    boolean flag=false;
    Pattern name=Pattern.compile("(?=,*[0-9])[A-Za-z0-9,\\s]+");
    Matcher nameMatch=name.matcher(address);
    if(nameMatch.matches())
    {
        flag=true;
    }
    else
    {
        flag=false;
    }
    return flag;
    }

    
    public boolean validateNum(String mobnum) throws BankAccountException
    {
    boolean flag=false;
    Pattern name=Pattern.compile("[0-9]{10}");
    Matcher nameMatch=name.matcher(mobnum);
    if(nameMatch.matches())
    {
        flag=true;
    }
    else
    {
        flag=false;
    }
    return flag;
    }
    
    
    public boolean validateAadhaar(String aadhaar) throws BankAccountException
    {
    boolean flag=false;
    Pattern name=Pattern.compile("^[0-9]{12}");
    Matcher nameMatch=name.matcher(aadhaar);
    if(nameMatch.matches())
    {
        flag=true;
    }
    else
    {
        flag=false;
    }
    return flag;
    }
    
    
    
    
    public boolean validatePan(String pan) throws BankAccountException
    {
    boolean flag=false;
    Pattern name=Pattern.compile("[A-Z0-9]{10}");
    Matcher nameMatch=name.matcher(pan);
    if(nameMatch.matches())
    {
        flag=true;
    }
    else
    {
        flag=false;
    }
    return flag;
    }
    

    
    public boolean validateBalance(double balance) throws BankAccountException
    {
    boolean flag=false;
    if(balance>=0)
    {
        flag=true;
    }
    else
    {
        flag=false;
    }
    return flag;
    }
    
    
    
    public boolean createAccount(Customer c) {
       d=new Dao();
       return d.createAccount(c);
    }


    
    public Customer customerDetails(long accnum) {

        return d.customerDetails(accnum);
    }


    public double showBalance(long accnum) throws BankAccountException {
        
        double bal = 0;
        
        check=d.validateAccnum(accnum);
      if(check==1)
      {
        Customer c= d.showBalance(accnum);
        bal = c.getBalance();
      }
      else
      {
          throw new BankAccountException("Invalid account");
      }
      return bal;
    }
    
    public double deposit(long accnum,double amount) throws BankAccountException{

        double dep = 0;
        
        check=d.validateAccnum(accnum);
      if(check==1)
      {
        Customer c= d.deposit(accnum, amount);
             dep = c.getBalance() + amount;
             c.setBalance(dep);
             String log = amount+" is Deposited";
             d.saveTransaction(accnum, log);
      }
      else
      {
          throw new BankAccountException("Invalid account");
      }
      return dep;

    }
    
    
    public double withdraw(long accnum, double amount) throws BankAccountException{
        
        double wd = 0;
        
        check=d.validateAccnum(accnum);
      if(check==1)
      {
        Customer c= d.withdraw(accnum, amount);
        if (amount<=c.getBalance() ) {
            wd = c.getBalance() - amount;
            c.setBalance(wd);
            String log = amount+" is Withdrawn";
            d.saveTransaction(accnum, log);
        }
        else
        {
          throw new BankAccountException("Invalid account");
        }

      }
      
      return wd;

    }
    
    public String fundTransfer(long accnum,long accnum2, double amount) throws BankAccountException  {
        
        double check1,check2;
        String fund=null;
        
        check1=d.fundTransfer(accnum);
        check2=d.fundTransfer(accnum2);
        if(check1==0)
        {
            fund="invalid source account";
        }
        else if(check2==0)
        {
            fund="Invalid destination account";
        }
        else if(check1==1 && check2==1)
        {
            double b1=0,b2=0;

            b1=withdraw(accnum,amount);
            if(b1!=0) {
            b2=deposit(accnum2,amount);
            fund="After the fund transfer:\n Balance in the source account is "+b1+
                    " \n Balance in the destination account is "+b2;
            }

        }
        else
        {
            fund="Transfer failed";
        }
        return fund;
    }
    
    public List<String> printTransaction(long accnum){
        return d.printTransaction(accnum);
    }

    
    public Map<Long, Customer> getAllCustomerDetails(){
        d=new Dao();
         return d.getAllCustomerDetails();
     }
    
}