package com.capg.pp.ui;

import java.util.Map;
import java.util.Scanner;

import com.capg.pp.bean.Customer;
import com.capg.pp.service.Service;
import com.capg.pp.exception.*;


public class Ui{
    

    static long accountNumber=1000L;
    static Service s=new Service();
    
    public static void main(String[] args) throws BankAccountException  {
        try{
        
        
        int choice,cont,age;
        long accnum,accnum2,mobNum,aadhaar;
        double value,bal,balance,deposit,withdraw;
        String name,address,pan,fund;
        boolean result,b;
        Scanner sc = new Scanner(System.in);
        Scanner sc2 = new Scanner(System.in);
do {
    System.out.println("\nMenu\n");
    System.out.println("1.Create Account");
    System.out.println("2.Display Customer Details");
    System.out.println("3.Show Balance");
    System.out.println("4.Deposit");
    System.out.println("5.Withdraw");
    System.out.println("6.Fund Transfer");
    System.out.println("7.Print Transaction");
    System.out.println("8.Details of every customer");
    System.out.println("\nEnter your Choice");
    choice = sc.nextInt();
        
        
        switch (choice) {

        case 1:

            
            do{
                System.out.println("\nEnter Name [with Initial as capital]");
                name = sc2.nextLine();
                b=s.validateName(name);
                if(b==true)
                {
                    continue;
                }
                else
                {
                    System.out.println("\n name invalid");
                }
                }while(b==false);
            
            
            
            do{
                System.out.println("Enter Age [between 18 to 60]");
                age=sc.nextInt();
                b=s.validateAge(age);
                if(b==true)
                {
                    continue;
                }
                else
                {
                    System.out.println("\nage invalid");
                }
                }while(b==false);
            
            
            
            do{
                System.out.println("Enter Address");
                address = sc2.nextLine();
                b=s.validateAddress(address);
                if(b==true)
                {
                    continue;
                }
                else
                {
                    System.out.println("\naddress invalid");
                }
                }while(b==false);
            
            do{
                System.out.println("Enter mobile number [10 digits]");
                mobNum = sc.nextLong();
                String mob=Long.toString(mobNum);
                b=s.validateNum(mob);
                if(b==true)
                {
                    continue;
                }
                else
                {
                    System.out.println("Mobile Number invalid");
                }
                }while(b==false);
            
            do{
                System.out.println("enter aadhaar number [12 digits]");
                aadhaar=sc.nextLong();
                String aadhaarNum=Long.toString(aadhaar);
                b=s.validateAadhaar(aadhaarNum);
                if(b==true)
                {
                    continue;
                }
                else
                {
                    System.out.println("\naadhaar invalid");
                }
                }while(b==false);
            
            do{
                System.out.println("enter Pan number [10 characters]");
                pan=sc.next();
                b=s.validatePan(pan);
                if(b==true)
                {
                    continue;
                }
                else
                {
                    System.out.println("pan invalid");
                }
                }while(b==false); 
 
            do{
                System.out.println("\nEnter the amount to be added to your account");
                bal = sc.nextDouble();
                b=s.validateBalance(bal);
                if(b==true)
                {
                    continue;
                }
                else
                {
                    System.out.println("Invalid amount");
                }
                }while(b==false);
  

            Customer c=new Customer();
            c.setName(name);
            c.setMobNum(mobNum);
            c.setAddress(address);
            c.setAadhaar(aadhaar);
            c.setPan(pan);
            c.setBalance(bal);
            c.setAccountNum(accountNumber);
            result=s.createAccount(c);
            accountNumber++;
            if(result)
            {
                System.out.println("Account created successfully and your account number is "+ c.getAccountNum());
            }
            else
            {
                System.out.println("Account not created");
            }
            break;
        case 2:
            
            System.out.println("enter account number");
            accnum=sc.nextLong();
            System.out.println("Customer details");
            System.out.println(s.customerDetails(accnum));
            break;
        case 3:
            System.out.println("enter account number");
            accnum=sc.nextLong();
            balance=s.showBalance(accnum);
            System.out.println("Balance is "+balance);
            break;
        case 4:
            System.out.println("enter account number");
            accnum=sc.nextLong();
            System.out.println("enter amount");
            value=sc.nextDouble();
            deposit=s.deposit(accnum,value);
            System.out.println("Amount Deposited and Rs."+deposit+ " is balance ");
            break;
        case 5:
            System.out.println("enter account number");
            accnum=sc.nextLong();
            System.out.println("enter amount");
            value=sc.nextDouble();
            withdraw=s.withdraw(accnum,value);
            System.out.println("Money withdrawn and the balance is"+withdraw);
            break;
        case 6:
            System.out.println("enter account number");
            accnum=sc.nextLong();
            System.out.println("enter account number to be transferred");
            accnum2=sc.nextLong();
            System.out.println("enter amount");
            value=sc.nextDouble();
            fund=s.fundTransfer(accnum,accnum2,value);
            System.out.println(fund);
            break;
        case 7:
            System.out.println("enter account number");
            accnum=sc.nextLong();
            System.out.println("Transactions");
            System.out.println(s.printTransaction(accnum));
            break;
        case 8:
            System.out.println("All Customer Details");
            Map<Long, Customer> ll=s.getAllCustomerDetails();
            ll.values().stream().forEach(System.out::println);
            break;
        default:
            System.out.println("wrong choice");
            break;
        }
        System.out.println("Are you want to continue transaction?(press 1 for yes)");
        cont=sc.nextInt();
        
    }while(cont==1);
sc.close();
sc2.close();
        }
        
        catch(Exception e)
        {
            System.out.println(e);
            throw new BankAccountException("Exception Occured");
        }

    }
}
